## setup

```
$ ansible-playbook -i production setup.yml
```
