package main

const Name string = "benchmarker"
const Version string = "0.1.0"
