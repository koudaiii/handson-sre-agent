<div class="isu-posts">
  <?php foreach ($posts as $post): ?>
    <?php require __DIR__ . '/post.php' ?>
  <?php endforeach ?>
</div>

