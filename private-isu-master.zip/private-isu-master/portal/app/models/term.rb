class Term < ActiveRecord::Base
end
